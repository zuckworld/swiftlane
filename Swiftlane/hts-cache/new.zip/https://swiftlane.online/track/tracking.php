 
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tracking Result - Webcrack Cargo</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/feather-icons"></script>
    <style>
        :root {
            --bg-dark-primary: #111827;
            --bg-dark-secondary: #1F2937;
            --accent-primary: #4F46E5;
            --accent-secondary: #6366F1;
            --text-primary: #F3F4F6;
            --text-secondary: #9CA3AF;
        }
        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--bg-dark-primary);
            color: var(--text-primary);
        }
        .card {
            background-color: var(--bg-dark-secondary);
            border: 1px solid #374151;
        }
        .desktop-nav { transition: width 0.3s ease; }
        .desktop-nav .nav-text { opacity: 0; transition: opacity 0.2s ease; }
        .desktop-nav:hover .nav-text { opacity: 1; }
        .fab-menu-button { transition: transform 0.3s ease-in-out, box-shadow 0.3s ease; }
        .fab-menu-button.active { transform: rotate(45deg); }
        .fab-menu-items { transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1), opacity 0.3s ease; transform-origin: bottom center; }
        .fab-menu-item { transition: transform 0.3s ease, opacity 0.3s ease; }

        .progress-line { height: 4px; width: 100%; position: absolute; top: 50%; transform: translateY(-50%); z-index: 1; }
        .progress-dot { box-shadow: 0 0 0 4px var(--bg-dark-secondary), 0 0 0 6px #374151; z-index: 2; transition: box-shadow 0.3s ease; }
        .progress-dot.active { box-shadow: 0 0 0 4px var(--bg-dark-secondary), 0 0 0 6px var(--accent-secondary); }
        .history-item::before { content: ''; position: absolute; left: -25px; top: 8px; width: 10px; height: 10px; border-radius: 50%; background-color: #4B5563; border: 2px solid var(--bg-dark-secondary); transition: background-color 0.3s ease; }
        .history-item.active::before { background-color: var(--accent-primary); }

        .tracking-results-container {
            transition: opacity 0.5s ease-in-out, transform 0.5s ease-in-out;
        }
    </style>
</head>
<body>

    <div id="preloader" class="fixed inset-0 bg-gray-900 z-50 flex justify-center items-center transition-opacity duration-500">
        <div class="flex flex-col items-center">
             <svg class="h-16 w-16 text-indigo-400 animate-pulse" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5-10-5-10 5z"/></svg>
            <p class="mt-4 text-lg font-semibold text-gray-300">Loading Shipment Data...</p>
        </div>
    </div>

    <div class="flex">
        <!-- Desktop Sidebar Navigation -->
        <nav class="desktop-nav hidden md:block fixed left-0 top-0 h-full bg-gray-800 shadow-lg w-20 hover:w-56 z-30 group">
            <ul class="flex flex-col h-full py-4 space-y-2">
                <li class="px-5 py-3 mb-4">
                    <a href="index.html" class="flex items-center space-x-2">
                        <svg class="h-10 w-10 text-indigo-400 flex-shrink-0" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5-10-5-10 5z"/></svg>
                        <span class="nav-text text-xl font-extrabold text-white whitespace-nowrap">Swiftlane Online</span>
                    </a>
                </li>
                 <li><a href="index.html" class="flex items-center py-3 px-6 text-gray-300 hover:bg-indigo-600 hover:text-white rounded-r-full transition-colors duration-200"><i data-feather="home" class="h-6 w-6 flex-shrink-0"></i><span class="nav-text ml-4 font-semibold whitespace-nowrap">Home</span></a></li>
                <li><a href="services.html" class="flex items-center py-3 px-6 text-gray-300 hover:bg-indigo-600 hover:text-white rounded-r-full transition-colors duration-200"><i data-feather="grid" class="h-6 w-6 flex-shrink-0"></i><span class="nav-text ml-4 font-semibold whitespace-nowrap">Services</span></a></li>
                <li><a href="about.html" class="flex items-center py-3 px-6 text-gray-300 hover:bg-indigo-600 hover:text-white rounded-r-full transition-colors duration-200"><i data-feather="info" class="h-6 w-6 flex-shrink-0"></i><span class="nav-text ml-4 font-semibold whitespace-nowrap">About</span></a></li>
                <li><a href="contact.html" class="flex items-center py-3 px-6 text-gray-300 hover:bg-indigo-600 hover:text-white rounded-r-full transition-colors duration-200"><i data-feather="phone" class="h-6 w-6 flex-shrink-0"></i><span class="nav-text ml-4 font-semibold whitespace-nowrap">Contact</span></a></li>
                <li class="mt-auto"><a href="track.html" class="flex items-center py-3 px-6 text-indigo-400 bg-gray-900"><i data-feather="compass" class="h-6 w-6 flex-shrink-0"></i><span class="nav-text ml-4 font-semibold whitespace-nowrap">Track Shipment</span></a></li>
            </ul>
        </nav>

        <div id="app-content" class="opacity-0 transition-opacity duration-500 w-full md:pl-20">
             <header class="md:hidden bg-gray-800/80 backdrop-blur-sm sticky top-0 z-10">
                <div class="container mx-auto px-4 sm:px-6 lg:px-8">
                    <div class="flex justify-between items-center py-4">
                        <div class="flex items-center space-x-2">
                            <svg class="h-8 w-8 text-indigo-400" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5-10-5-10 5z"/></svg>
                            <span class="text-xl font-extrabold text-white">Webcrack Cargo</span>
                        </div>
                    </div>
                </div>
            </header>

            <main class="container mx-auto p-4 sm:p-6 lg:p-8">
                 <div class="card rounded-2xl shadow-lg p-6 md:p-8 mb-8">
                    <h2 class="text-2xl md:text-3xl font-bold text-white mb-2">Track Your Shipment</h2>
                    <p class="text-text-secondary mb-6">Enter your tracking number to get real-time updates.</p>
                    <form action="tracking.php" method="POST" class="flex flex-col sm:flex-row items-center gap-3">
                        <div class="relative flex-grow w-full">
                            <i data-feather="hash" class="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400"></i>
                            <input type="text" name="search_P" value="" placeholder="Enter your tracking number" class="w-full pl-12 pr-4 py-3 bg-gray-900 border border-gray-600 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all text-white">
                        </div>
                        <button type="submit" name="search" class="w-full sm:w-auto flex items-center justify-center gap-2 bg-indigo-600 text-white font-semibold px-6 py-3 rounded-xl hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 focus:ring-offset-gray-900 transition-all duration-300 shadow-lg hover:shadow-indigo-500/50">
                            <i data-feather="search" class="h-5 w-5"></i>
                            <span>Track Now</span>
                        </button>
                    </form>
                </div>
                
                            </main>
        </div>
    </div>

    <!-- Mobile Floating Action Button Menu -->
    <div class="fixed md:hidden bottom-0 left-1/2 -translate-x-1/2 w-full max-w-md px-4 pb-4 z-20">
        <div class="relative flex items-center justify-center">
            <div id="fab-menu-items" class="fab-menu-items absolute bottom-0 flex justify-center items-end gap-4 mb-20 opacity-0 transform scale-90 pointer-events-none">
                <a href="index.html" class="fab-menu-item flex flex-col items-center text-text-secondary hover:text-white transition-all transform hover:-translate-y-1" style="transition-delay: 0.2s"><div class="bg-white rounded-full p-3 shadow-lg"><i data-feather="home" class="h-6 w-6 text-indigo-600"></i></div><span class="text-xs font-semibold mt-1">Home</span></a>
                <a href="services.html" class="fab-menu-item flex flex-col items-center text-text-secondary hover:text-white transition-all transform hover:-translate-y-1" style="transition-delay: 0.1s"><div class="bg-white rounded-full p-3 shadow-lg"><i data-feather="grid" class="h-6 w-6 text-indigo-600"></i></div><span class="text-xs font-semibold mt-1">Services</span></a>
                <a href="about.html" class="fab-menu-item flex flex-col items-center text-text-secondary hover:text-white transition-all transform hover:-translate-y-1" style="transition-delay: 0.1s"><div class="bg-white rounded-full p-3 shadow-lg"><i data-feather="info" class="h-6 w-6 text-indigo-600"></i></div><span class="text-xs font-semibold mt-1">About</span></a>
                <a href="contact.html" class="fab-menu-item flex flex-col items-center text-text-secondary hover:text-white transition-all transform hover:-translate-y-1" style="transition-delay: 0.2s"><div class="bg-white rounded-full p-3 shadow-lg"><i data-feather="phone" class="h-6 w-6 text-indigo-600"></i></div><span class="text-xs font-semibold mt-1">Contact</span></a>
            </div>
            <button id="fab-menu-button" class="fab-menu-button relative bg-indigo-600 text-white rounded-full h-16 w-16 flex items-center justify-center shadow-xl hover:shadow-2xl hover:shadow-indigo-500/50 hover:bg-indigo-700"><i data-feather="plus" class="h-8 w-8 transition-transform duration-300"></i></button>
        </div>
    </div>

    <script>
        feather.replace();

        function updateProgressBar(status) {
            const progressBar = document.getElementById('progress-bar');
            const dots = [document.getElementById('dot-1'), document.getElementById('dot-2'), document.getElementById('dot-3'), document.getElementById('dot-4')];
            const labels = [document.getElementById('label-1'), document.getElementById('label-2'), document.getElementById('label-3'), document.getElementById('label-4')];
            
            let progressLevel = 0;
            if (status.toLowerCase().includes('transit')) progressLevel = 1;
            if (status.toLowerCase().includes('out for delivery')) progressLevel = 2;
            if (status.toLowerCase().includes('delivered')) progressLevel = 3;

            const progressPercentage = { 0: 0, 1: 33, 2: 66, 3: 100 };
            progressBar.style.width = `${progressPercentage[progressLevel] || 0}%`;

            dots.forEach((dot, index) => {
                if (index <= progressLevel) {
                    dot.classList.add('active');
                    labels[index].classList.add('font-semibold', 'text-white');
                } else {
                    dot.classList.remove('active');
                    labels[index].classList.remove('font-semibold', 'text-white');
                }
            });
        }

        window.addEventListener('load', () => {
            const preloader = document.getElementById('preloader');
            const content = document.getElementById('app-content');
            setTimeout(() => {
                preloader.style.opacity = '0';
                content.style.opacity = '1';
                setTimeout(() => {
                    preloader.style.display = 'none';
                    const results = document.getElementById('tracking-results');
                    if(results) {
                        results.classList.remove('opacity-0', '-translate-y-4');
                                            }
                }, 500);
            }, 1000); 
        });

        const fabButton = document.getElementById('fab-menu-button');
        const fabMenuItemsContainer = document.getElementById('fab-menu-items');
        if (fabButton) {
            fabButton.addEventListener('click', () => {
                const isActive = fabButton.classList.toggle('active');
                if (isActive) {
                    fabMenuItemsContainer.classList.remove('opacity-0', 'scale-90', 'pointer-events-none');
                } else {
                    fabMenuItemsContainer.classList.add('opacity-0', 'scale-90');
                     setTimeout(() => {
                        fabMenuItemsContainer.classList.add('pointer-events-none');
                    }, 300);
                }
            });
        }
    </script>
</body>
</html>
